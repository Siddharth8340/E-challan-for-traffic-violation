# E-CHALLAN-For-Traffic-Violation
An organized and smart Traffic penalty management system


* THIS PROJECT IS MADE USING HTML AND mysQL AND THE CONNECTION IS MADE USING php.
* THE ESSESNTIAL LINKS AND SOFTWARE NEEDED FOR THIS PROJECT IMPLEMENTATION ARE AS FOLLOWS:
	1. https://materializecss.com/ : This link is useful in front end development , It provides useful component codes in css and javascript to 
                                 add the components in front end.
	2. wampserver-3.14: An executable file is present along with other important installation in executable format for development of back end 
 	                   and making connection using PHP.
 
* ALL SOURCE CODES OF FRONT END AND BACK END ARE PRESENT IN THE SOURCE CODE FOLDER.
* CREATE A SERVER USING SOFTWARES LIKE WAMPSERVER AND MAKE THE BACK END
* UPLOAD THE WEBPAGES IN THE SERVER.
* NOW ACCESS THE SITE USING LOCAL HOST.




THIS PROJECT IS MADE BY GUNJALA SIDDHARTH 
For any further queries please feel free to contact me  on siddharthgunjala8765@gmail.com.

