<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>
<nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo center">E-CHALLAN</a>
      
    </div>
  </nav>





<div class="row">
    <div class="col s12 m6">
      <div class="card blue-grey darken-1">
        <div class="card-content yellow-text">
          <span class="card-title"><center>SUCESSFULLY ISSUED</center></span>
	</div>
	<div class="card-content white-text">
          <p><center>The challan was issued successfully.<center></p>
        </div>
        </div>
      </div>
    </div>
  </div>











<footer class="page-footer">
     
		<div class="container">
            <div class="row">
              <div class="col 23 s29">
                <h5 class="white-text">TRAFFIC POLICE</h5>
                <p class="grey-text text-lighten-4">Drive safe and be safe</p>
              </div>
	  
              <div class="col 14 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">HOME</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">PAY CHALLAN</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">ISSUE CHALLAN</a></li>
           
                </ul>
              </div>
            </div>
          </div>

          <div class="footer-copyright">
       
            <div class="container">
         
           <CENTER> � Gunjala Siddharth
            </CENTER>
  
            </div>
          </div>
        </footer>
      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="js/materialize.min.js"></script>
    </body>
  </html>







